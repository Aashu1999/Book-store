import { Route } from '@angular/compiler/src/core';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { title } from 'process';
import { BookList, CartService } from '../cart.service';

@Component({
  selector: 'app-book-list',
  templateUrl: './book-list.component.html',
  styleUrls: ['./book-list.component.css']
})
export class BookListComponent implements OnInit {
  filteredBooks: BookList[];
  allBooks: BookList[];

  constructor(private cartService:CartService, private router:Router) { }

  ngOnInit() {
    this.cartService.getAllBooks().subscribe(data=>{
      this.filteredBooks = this.allBooks= data.slice();
    });
  };

  search(value){
      let type = "title";
      this.filteredBooks = this.allBooks.filter((item)=>{
        return item[type].toUpperCase().includes(value.target.value.toUpperCase());
      })
    }

}
