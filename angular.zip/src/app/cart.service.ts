import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
export class BookList{
constructor(
  public bookId:number,
	public title: String,
	public author: String,
	public description: String,
	public rating:number,
	public price:number
){}
}
export class CartList{
  constructor(
    public cartId:number,
    public bookId: number,
    public quantity: number,
    public totalCost: number,
  ){}
  }
@Injectable()
export class CartService {

  constructor(private http:HttpClient) { 

  }
  getAllBooks(): Observable<any> { 
    console.log("Test call")
    return this.http.get("http://localhost:8110/cart/getAllBooks");
  }
  

}
